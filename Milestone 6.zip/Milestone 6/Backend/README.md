# SE-Project-STS
Software Engineering project - Student Ticketing System

- Run following command to setup the project as per requirements.txt
`sh local_setup.sh`
