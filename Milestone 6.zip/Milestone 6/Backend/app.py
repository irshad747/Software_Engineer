import datetime
import os
import requests
from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required
from flask_restful import Api
from werkzeug.security import check_password_hash

from custom_error import DataError, LogicError
from Login_manager_api import Login_api
from mail_config import send_email
from model import Staff, Subject_Tag, User, db, Ticket
from Response_api_for_TM import Responses_api
from Role_manager_api import Role_api
from Tag_manager_api import Tag_api
from Ticket_manager_api import Ticket_api

# Configurations
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///'+os.getcwd() + \
    '/DB_project.sqlite3'
api = Api(app)

app.config['SECRET_KEY'] = 'FMM-2'
CORS(app)
JWTManager(app)
db.init_app(app)
app.app_context().push()
db.create_all()

# API URLS
api.add_resource(Login_api, '/api/register', '/api/login/<string:email>')
api.add_resource(Role_api, '/api/role', '/api/role/<int:user_id>')
api.add_resource(Ticket_api, '/api/subject/ticket/<int:ticket_id>',
                 '/api/subject/<string:subject_name>')
api.add_resource(Responses_api, '/api/response', '/api/response/<int:ticket_id>',
                 '/api/response/<int:ticket_id>/<int:response_id>')
api.add_resource(Tag_api,
                 '/api/tag/<string:tag_type>', '/api/tag/<string:tag_type>/<int:tag_id>')

# Controllers
@app.route('/')
def flask_test():
    return 'Testing, Flask!'

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = request.get_json()
    username = form.get("username")
    password = form.get("password")
    user = User.query.filter_by(username=username).first()
    user_id = int(user.user_id)
    print(user_id)
    if not user:
        raise DataError(status_code=404)
    if check_password_hash(pwhash=user.password, password=password):
        if user.role == 'staff':
            staff = Staff.query.filter_by(user_id=user_id).first()
            if staff.status == False:
                raise LogicError(status_code=400, error_code="USER006",
                                 error_msg="The staff is unapproved. Please wait for approval")
            else:
                expire_time = datetime.timedelta(days=1)
                access_token = create_access_token(
                    identity=username, expires_delta=expire_time)
                return {'access_token': access_token, 'role': user.role, "user_id": user.user_id, "subject_name": Subject_Tag.query.filter_by(subject_id=staff.subject_id).first().subject_name}, 200

        expire_time = datetime.timedelta(days=1)
        access_token = create_access_token(
            identity=username, expires_delta=expire_time)
        return {'access_token': access_token, 'role': user.role, "user_id": user.user_id}, 200
    else:
        raise LogicError(status_code=400, error_code="USER005",
                         error_msg="Either username or password is incorrect")


@app.route('/notify/<string:role>', methods=['POST'])
@jwt_required()
def notifyMail(role):
    form = request.get_json()
    ticket_id = form.get('ticket_id')
    if ticket_id is None:
        # if ticket-id is missing raise error
        raise DataError(status_code=400)

    if role == 'student':
        # Sending specific notification to students abt their ticket status
        token = request.headers['Authorization']
        ticket_data = requests.get(request.url_root + 'api/response/' +
                             ticket_id, headers={'Authorization': token}).json()
        author = User.query.filter_by(
            user_id=ticket_data.get('user_id')).first()
        if get_jwt_identity() != author.username:
            # Checking if the ticket's author posted the response then no notfication
            send_email(to=author.email, subject="New response is posted in your ticket",
                       msg=render_template('mail_body_student.html', username=author.username,
                                           response=ticket_data.get('response_list')[-1]))
    else:
        # Sending notification to respective staff that new ticket has been created
        subject_name = form.get('subject_name')
        token = request.headers['Authorization']
        staff_list = requests.get(request.url_root + 'api/role?status=1',
                            headers={'Authorization': token}).json()

        staff_list = filter(lambda x: x.get('subject_name') == subject_name,
                            staff_list)
        ticket_data = requests.get(request.url_root + 'api/response/' +
                             str(ticket_id), headers={'Authorization': token}).json()
        for staff in staff_list:
            # print(staff)
            send_email(to=staff.get('email'), subject="New Ticket is created",
                       msg=render_template('mail_body_staff.html', username=staff.get('username'), ticket=ticket_data))

    return 'Success', 200

DISCOURSE_API_BASE_URL = 'http://localhost:4200/'
DISCOURSE_API_KEY = '6f0cf975bd773a3d90b3a7031e337b27158081acce675c42988a1aa00fd53583'
DISCOURSE_API_USERNAME = 'anshgoyal231002'

@app.route('/create_ticket/<int:ticket_id>', methods=['POST'])
def create_ticket(data):
    title = data['title']
    raw = data['raw']
    if len(title)<15:
        return 'title should be greater than 15 letter', 422
    elif len(raw)<20:
        return 'body should be greater than 20 letter', 422
    # Headers
    headers = {
        'api_key': DISCOURSE_API_KEY,
        'api_username': DISCOURSE_API_USERNAME
    }
    # Create a new topic (ticket) on Discourse
    discourse_payload = {
        'title': title,
        'raw': raw,
        "category": 4
    }

    response = requests.post(f'{DISCOURSE_API_BASE_URL}/posts.json', json=discourse_payload, headers=headers)

    if response.status_code == 200:
        return 'Title created successfully' , response.json()['id']
    else:
        return 'Error', response.json()['errors']

@app.route('/get_ticket/<int:topic_id>', methods=['GET'])
def get_ticket(topic_id):
    # Fetch topic details from Discourse
    discourse_response = requests.get(f'{DISCOURSE_API_BASE_URL}/posts/{topic_id}.json')
    if discourse_response.status_code == 200:
        topic_data = discourse_response.json()
        return jsonify(topic_data), 200
    else:
        return jsonify({'error': 'Ticket not found on Discourse'}), 404
    

# Similar implementations for update_ticket and delete_ticket APIs...
@app.route('/get_all_tickets', methods=['GET'])
def get_all_tickets():
    headers = {
        'api_key': DISCOURSE_API_KEY,
        'api_username': DISCOURSE_API_USERNAME
    }
    response = requests.get(f'{DISCOURSE_API_BASE_URL}/posts.json')
    return response

@app.route('/update_ticket/<int:ticket_id>', methods=['PUT'])
def update_ticket(data):
    ticket_id = data.get('id')
    content = data.get('content')

    # Headers
    headers = {
        'api_key': DISCOURSE_API_KEY,
        'api_username': DISCOURSE_API_USERNAME
    }

    # Construct the payload for updating the ticket on Discourse
    discourse_payload = {
  "post": {
    "raw": content
  }
}

    # Make a PUT request to update the ticket on Discourse
    discourse_response = requests.put(f'{DISCOURSE_API_BASE_URL}/posts/{ticket_id}.json', json=discourse_payload, headers=headers)

    if discourse_response.status_code == 200:
        # Ticket updated successfully
        return jsonify({'message': 'Ticket updated successfully'}), 200
    else:
        # Failed to update ticket on Discourse
        return jsonify({'error': 'Failed to update ticket on Discourse'}), 500


@app.route('/delete_ticket/<int:ticket_id>', methods=['DELETE'])
def delete_ticket(ticket_id):
    # Headers
    headers = {
        'api_key': DISCOURSE_API_KEY,
        'api_username': DISCOURSE_API_USERNAME,
    }

    # Make a DELETE request to delete the ticket on Discourse
    discourse_response = requests.delete(f'{DISCOURSE_API_BASE_URL}/t/{ticket_id}.json', headers=headers)

    if discourse_response.status_code == 200:
        # Ticket deleted successfully
        return jsonify({'message': 'Ticket deleted successfully'}), 200
    else:
        # Failed to delete ticket on Discourse
        return jsonify({'error': 'Failed to delete ticket on Discourse'}), 500

def get_likes(ticket_id):
    # actions_summary.count
    pass
if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port='5500')