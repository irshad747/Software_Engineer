from app import *
import pytest
from app import app
# def test_index_route():
#     response = app.test_client().get('/')

#     assert response.status_code == 200
#     assert response.data.decode('utf-8') == 'Testing, Flask!'

@pytest.fixture
def inventory():
# import requests
    DISCOURSE_API_BASE_URL = 'http://localhost:4200/'
    DISCOURSE_API_KEY = '6f0cf975bd773a3d90b3a7031e337b27158081acce675c42988a1aa00fd53583'
    DISCOURSE_API_USERNAME = 'anshgoyal231002'
    data = {'title': 'hello abjdkfbcsnzodvs cfb',
            'content':'niadb uwiead ibwe hello how are you'}

    return DISCOURSE_API_BASE_URL, DISCOURSE_API_KEY, DISCOURSE_API_USERNAME

# response = requests.get('http://localhost:4200/admin/users/list/active.json')
# print(response)
# def test_create():
#     # request = "data = {'title': 'hello abjdkfbcsnzodvs cfb','content':'niadb uwiead ibwe hello how are you'}"
    
#     response = app.test_client().post(url = '/create_ticket/4')
#     assert response.status_code == 200


def test_get_post(inventory):
    id = 40
    response = get_ticket(id)
    if response[1] == 200:

        print(id, '---', response[0].json['raw'])
    elif response[1] == 404:
        print(id, '---', response[0].json['error'])


def test_get_posts(inventory):
    response = get_all_tickets()
    assert response.status_code == 200
    data = response.json()['latest_posts']
    for i in data:
        print(i['id'], i['raw'])
        print('\n')


#creating a new ticket in general category
def test_create_post():
    result = create_ticket({"title": "title is the new title1", "raw": "raw content string ecdkjifndoas cenrsinsdzxcie cnfixncdsd"})
    print(result)

#Updating ticket Test
def test_update_ticket():
    result = update_ticket({'id': 40, 'content': 'this is new raw content instead of old one'})
    print(result[0].json)

#Delete Ticket Test
def test_delete_ticket():
    result = delete_ticket(31)
    # assert (result[1].status_code) == 200
    print(result[1])
